# SPDX-FileCopyrightText: 2018-2022 James R. Barlow
# SPDX-FileCopyrightText: 2019 Martin Wind
# SPDX-License-Identifier: MPL-2.0

"""OCRmyPDF page processing pipeline functions."""

from __future__ import annotations

import logging
import os
import re
import sys
from collections.abc import Iterable, Iterator, Sequence
from contextlib import suppress
from io import BytesIO
from pathlib import Path
from shutil import copyfileobj
from typing import TYPE_CHECKING, BinaryIO, TypeVar, cast

if TYPE_CHECKING:
    from pikepdf.pdfa import Report

    from ocrmypdf.hocrtransform import OcrElement

import img2pdf
import pikepdf
from PIL import Image, ImageColor, ImageDraw

from ocrmypdf._concurrent import Executor
from ocrmypdf._exec import unpaper
from ocrmypdf._jobcontext import PageContext, PdfContext
from ocrmypdf._metadata import metadata_fixup, repair_docinfo_nuls
from ocrmypdf._options import OcrOptions, PathOrIO, ProcessingMode, TaggedPdfMode
from ocrmypdf._pageboxes import log_box_repairs, repair_page_boxes
from ocrmypdf._stdoutprotect import get_protected_stdout_fd
from ocrmypdf.exceptions import (
    ColorConversionNeededError,
    DigitalSignatureError,
    DpiError,
    EncryptedPdfError,
    InputFileError,
    NonEmbeddedFontsError,
    PdfaConversionFailedError,
    PriorOcrFoundError,
    SubprocessOutputError,
    TaggedPDFError,
    UnsupportedImageFormatError,
)
from ocrmypdf.helpers import IMG2PDF_KWARGS, Resolution, safe_symlink
from ocrmypdf.imageops import (
    calculate_downsample,
    downsample_image,
    has_decoded_pixels,
)
from ocrmypdf.pdfa import (
    add_simple_font_tounicode,
    file_claims_pdfa,
    find_nonembedded_cid_fonts,
    generate_pdfa_ps,
    log_prepare_result,
    output_type_to_flavour,
    repair_annotations_for_ghostscript,
    speculative_pdfa_conversion,
)
from ocrmypdf.pdfa import (
    get_pdf_save_settings as get_pdf_save_settings,  # re-exported
)
from ocrmypdf.pdfinfo import Colorspace, Encoding, FloatRect, Ink, PageInfo, PdfInfo
from ocrmypdf.pdfinfo.info import PageResolutionProfile
from ocrmypdf.pluginspec import GhostscriptRasterDevice, OrientationConfidence

try:
    from pillow_heif import register_heif_opener
except ImportError:

    def register_heif_opener(**kwargs) -> None:
        pass


T = TypeVar("T")
log = logging.getLogger(__name__)

VECTOR_PAGE_DPI = 400


register_heif_opener()


def triage_image_file(input_file: Path, output_file: Path, options: OcrOptions) -> None:
    """Triage the input image file.

    If the input file is an image, check its resolution and convert it to PDF.

    Args:
        input_file: The path to the input file.
        output_file: The path to the output file.
        options: An object containing the options passed to the OCRmyPDF command.

    Raises:
        UnsupportedImageFormatError: If the input file is not a supported image format.
        DpiError: If the input image has no resolution (DPI) in its metadata or if the
            resolution is not credible.
    """
    log.info("Input file is not a PDF, checking if it is an image...")
    try:
        im = Image.open(input_file)
    except OSError as e:
        # Recover the original filename
        log.error(str(e).replace(str(input_file), str(options.input_file)))
        if not input_file.exists():
            log.error("Input file does not exist: %s", input_file)
        if input_file.is_dir():
            log.error("Input file is a directory: %s", input_file)
        if input_file.is_file():
            log.error("Input file is a file: %s", input_file)
        if input_file.stat().st_size == 0:
            log.error("Input file is empty: %s", input_file)
        raise UnsupportedImageFormatError() from e

    with im:
        log.info("Input file is an image")
        if 'dpi' in im.info:
            if im.info['dpi'] <= (96, 96) and not options.image_dpi:
                log.info("Image size: (%d, %d)", *im.size)
                log.info("Image resolution: (%d, %d)", *im.info['dpi'])
                raise DpiError(
                    "Input file is an image, but the resolution (DPI) is "
                    "not credible.  Estimate the resolution at which the "
                    "image was scanned and specify it using --image-dpi."
                )
        elif not options.image_dpi:
            log.info("Image size: (%d, %d)", *im.size)
            raise DpiError(
                "Input file is an image, but has no resolution (DPI) "
                "in its metadata.  Estimate the resolution at which "
                "image was scanned and specify it using --image-dpi."
            )

        if im.mode in ('RGBA', 'LA'):
            raise UnsupportedImageFormatError(
                "The input image has an alpha channel. Remove the alpha channel first."
            )

        if 'iccprofile' not in im.info:
            if im.mode == 'RGB':
                log.info("Input image has no ICC profile, assuming sRGB")
            elif im.mode == 'CMYK':
                raise UnsupportedImageFormatError(
                    "Input CMYK image has no ICC profile, not usable"
                )

    try:
        log.info("Image seems valid. Try converting to PDF...")
        layout_fun = img2pdf.default_layout_fun
        if options.image_dpi:
            layout_fun = img2pdf.get_fixed_dpi_layout_fun(
                Resolution(options.image_dpi, options.image_dpi)
            )
        with output_file.open('wb') as outf:
            img2pdf.convert(
                os.fspath(input_file),
                layout_fun=layout_fun,
                outputstream=outf,
                **IMG2PDF_KWARGS,
            )
        log.info("Successfully converted to PDF, processing...")
    except img2pdf.ImageOpenError as e:
        raise UnsupportedImageFormatError() from e


def _pdf_guess_version(input_file: Path, search_window=1024) -> str:
    """Try to find version signature at start of file.

    Not robust enough to deal with appended files.

    Returns empty string if not found, indicating file is probably not PDF.
    """
    with input_file.open('rb') as f:
        signature = f.read(search_window)
    m = re.search(rb'%PDF-(\d\.\d)', signature)
    if m:
        return m.group(1).decode('ascii')
    return ''


def unwrap_single_filter_arrays(pdf: pikepdf.Pdf) -> None:
    """Rewrite ``/Filter [/X]`` as the equivalent ``/Filter /X``.

    When saving with ``compress_streams=True``, qpdf leaves streams already
    compressed with /FlateDecode untouched, but only recognizes the filter
    when it is a name. As a one-element array, qpdf decodes and recompresses
    the stream, discarding any predictor, which can inflate images by 30% or
    more (#1620).
    """
    for obj in pdf.objects:
        if not isinstance(obj, pikepdf.Stream):
            continue
        filter_ = obj.get(pikepdf.Name.Filter)
        if not isinstance(filter_, pikepdf.Array) or len(filter_) != 1:
            continue
        decodeparms = obj.get(pikepdf.Name.DecodeParms)
        if isinstance(decodeparms, pikepdf.Array):
            if len(decodeparms) != 1:
                continue
            if isinstance(decodeparms[0], pikepdf.Dictionary):
                obj.DecodeParms = decodeparms[0]
            else:
                del obj.DecodeParms
        obj.Filter = filter_[0]


def triage(
    original_filename: str, input_file: Path, output_file: Path, options: OcrOptions
) -> Path:
    """Triage the input file. We can handle PDFs and images."""
    try:
        if _pdf_guess_version(input_file):
            if options.image_dpi:
                log.warning(
                    "Argument --image-dpi is being ignored because the "
                    "input file is a PDF, not an image."
                )
            try:
                with pikepdf.open(input_file, conversion_mode='explicit') as pdf:
                    repairs_by_page = {
                        n: repairs
                        for n, page in enumerate(pdf.pages)
                        if (repairs := repair_page_boxes(page))
                    }
                    log_box_repairs(repairs_by_page)
                    unwrap_single_filter_arrays(pdf)
                    pdf.save(output_file)
            except pikepdf.PdfError as e:
                raise InputFileError() from e
            except pikepdf.PasswordError as e:
                raise EncryptedPdfError() from e
            return output_file
    except OSError as e:
        log.debug(f"Temporary file was at: {input_file}")
        msg = str(e).replace(str(input_file), original_filename)
        raise InputFileError(msg) from e

    triage_image_file(input_file, output_file, options)
    return output_file


def get_pdfinfo(
    input_file,
    *,
    executor: Executor,
    detailed_analysis: bool = False,
    progbar: bool = False,
    max_workers: int | None = None,
    use_threads: bool = True,
    check_pages=None,
) -> PdfInfo:
    """Get the PDF info."""
    try:
        return PdfInfo(
            input_file,
            detailed_analysis=detailed_analysis,
            progbar=progbar,
            max_workers=max_workers,
            use_threads=use_threads,
            check_pages=check_pages,
            executor=executor,
        )
    except pikepdf.PasswordError as e:
        raise EncryptedPdfError() from e
    except pikepdf.PdfError as e:
        raise InputFileError() from e


def validate_pdfinfo_options(context: PdfContext) -> None:
    """Validate the PDF info options."""
    pdfinfo = context.pdfinfo
    options = context.options

    if pdfinfo.needs_rendering:
        raise InputFileError(
            "This PDF contains dynamic XFA forms created by Adobe LiveCycle "
            "Designer and can only be read by Adobe Acrobat or Adobe Reader."
        )
    if pdfinfo.has_signature:
        if options.invalidate_digital_signatures:
            log.warning("All digital signatures will be invalidated")
        else:
            raise DigitalSignatureError()
    if pdfinfo.has_acroform:
        if options.mode == ProcessingMode.redo:
            raise InputFileError(
                "This PDF has a user fillable form. --redo-ocr (or --mode redo) "
                "is not currently possible on such files."
            )
        else:
            log.warning(
                "This PDF has a fillable form. "
                "Chances are it is a pure digital "
                "document that does not need OCR."
            )
            if not options.is_force_mode:
                log.info(
                    "Use the option --force-ocr (or --mode force) to produce an "
                    "image of the form and all filled form fields. The output PDF "
                    "will be 'flattened' and will no longer be fillable."
                )
    if pdfinfo.is_tagged or pdfinfo.has_structure_tree:
        log.warning(
            "This PDF contains structural markup (it is a Tagged PDF or "
            "carries a logical structure tree). This often indicates that the "
            "PDF was generated from an office document or is otherwise born "
            "digital, and does not need OCR. OCRmyPDF cannot rebuild this "
            "structure to match new text, so any page it re-OCRs with "
            "--force-ocr or --redo-ocr will have its structural markup "
            "discarded."
        )
        if (
            options.tagged_pdf_mode == TaggedPdfMode.default
            and options.mode == ProcessingMode.default
        ):
            log.info("Use --tagged-pdf-mode ignore to ignore Tagged PDFs.")
            raise TaggedPDFError()
    context.plugin_manager.validate(pdfinfo=pdfinfo, options=options)
    if options.mode == ProcessingMode.default:
        # Abort before any page is rasterized or OCR'd, rather than waiting
        # for a worker to reach the first page with text. is_ocr_required
        # performs the same check per page.
        for pageinfo in pdfinfo.pages:
            if pageinfo is None:
                continue
            if options.pages and pageinfo.pageno not in options.pages:
                continue
            if pageinfo.has_text:
                raise PriorOcrFoundError(
                    f"page {pageinfo.pageno + 1} already has text! - aborting "
                    "(use --force-ocr or --mode force to force OCR; see also help "
                    "for --skip-text, --redo-ocr, and --mode)"
                )


def _vector_page_dpi(pageinfo: PageInfo) -> int:
    """Get a DPI to use for pages with vector content or visible text.

    Invisible text, such as a prior OCR layer, does not need to be rasterized
    legibly, so it does not raise the DPI.
    """
    return VECTOR_PAGE_DPI if pageinfo.has_vector or pageinfo.has_visible_text else 0


def get_page_square_dpi(
    page_context: PageContext, image_dpi: Resolution | None = None
) -> Resolution:
    """Get the DPI when we require xres == yres, scaled to physical units.

    Page DPI includes UserUnit scaling.
    """
    pageinfo = page_context.pageinfo
    options = page_context.options
    if not image_dpi:
        image_dpi = pageinfo.dpi
    xres = image_dpi.x or 0.0
    yres = image_dpi.y or 0.0
    userunit = float(pageinfo.userunit) or 1.0
    units = float(
        max(
            (xres * userunit) or VECTOR_PAGE_DPI,
            (yres * userunit) or VECTOR_PAGE_DPI,
            _vector_page_dpi(pageinfo),
            options.oversample or 0.0,
        )
    )
    return Resolution(units, units)


def get_canvas_square_dpi(
    page_context: PageContext, image_dpi: Resolution | None = None
) -> Resolution:
    """Get the DPI when we require xres == yres, in Postscript units.

    Canvas DPI is independent of PDF UserUnit scaling, which is
    used to describe situations where the PDF user space is not 1:1 with
    the physical units of the page.
    """
    pageinfo = page_context.pageinfo
    options = page_context.options
    if not image_dpi:
        image_dpi = pageinfo.dpi
    units = float(
        max(
            image_dpi.x or VECTOR_PAGE_DPI,
            image_dpi.y or VECTOR_PAGE_DPI,
            _vector_page_dpi(pageinfo),
            options.oversample or 0.0,
        )
    )
    return Resolution(units, units)


def is_ocr_required(page_context: PageContext) -> bool:
    """Check if the page needs to be OCR'd."""
    pageinfo = page_context.pageinfo
    options = page_context.options

    if options.mode == ProcessingMode.strip_text:
        # Strip mode removes the OCR text layer in place; it never rasterizes
        # or runs OCR. The stripping happens in OcrGrafter.graft_page.
        return False

    ocr_required = True

    if options.pages and pageinfo.pageno not in options.pages:
        log.debug(f"skipped {pageinfo.pageno} as requested by --pages {options.pages}")
        ocr_required = False
    elif pageinfo.has_text:
        if options.mode == ProcessingMode.default:
            raise PriorOcrFoundError(
                "page already has text! - aborting (use --force-ocr or --mode force "
                "to force OCR; see also help for --skip-text, --redo-ocr, and --mode)"
            )
        elif options.is_force_mode:
            log.info("page already has text! - rasterizing text and running OCR anyway")
            ocr_required = True
        elif options.mode == ProcessingMode.redo:
            if pageinfo.has_corrupt_text:
                log.warning(
                    "some text on this page cannot be mapped to characters: "
                    "consider using --force-ocr (or --mode force) instead"
                )
            else:
                log.info("redoing OCR")
            ocr_required = True
        elif options.mode == ProcessingMode.skip:
            log.info("skipping all processing on this page")
            ocr_required = False
    elif not pageinfo.images and not options.lossless_reconstruction:
        # We found a page with no images and no text. That means it may
        # have vector art that the user wants to OCR. If we determined
        # lossless reconstruction is not possible then we have to rasterize
        # the image. So if OCR is being forced, take that to mean YES, go
        # ahead and rasterize. If not forced, then pretend there's no text
        # on the page at all so we don't lose anything.
        # This could be made smarter by explicitly searching for vector art.
        if options.is_force_mode and options.oversample:
            # The user really wants to reprocess this file
            log.info(
                "page has no images - "
                f"rasterizing at {options.oversample} DPI because "
                "--force-ocr --oversample (or --mode force --oversample) was specified"
            )
        elif options.is_force_mode:
            # Warn the user they might not want to do this
            log.warning(
                "page has no images - "
                "all vector content will be "
                f"rasterized at {VECTOR_PAGE_DPI} DPI, losing some resolution and "
                "likely increasing file size. Use --oversample to adjust the "
                "DPI."
            )
        else:
            log.info(
                "page has no images - "
                "skipping all processing on this page to avoid losing detail. "
                "Use --force-ocr (or --mode force) if you wish to perform OCR on "
                "pages that have vector content."
            )
            ocr_required = False

    if ocr_required and options.skip_big and pageinfo.images:
        pixel_count = pageinfo.width_pixels * pageinfo.height_pixels
        if pixel_count > (options.skip_big * 1_000_000):
            ocr_required = False
            log.warning(
                "page too big, skipping OCR "
                f"({(pixel_count / 1_000_000):.1f} MPixels > "
                f"{options.skip_big:.1f} MPixels --skip-big)"
            )
    return ocr_required


def rasterize_preview(input_file: Path, page_context: PageContext) -> Path:
    """Generate a lower quality preview image."""
    output_file = page_context.get_path('rasterize_preview.jpg')
    canvas_dpi = Resolution(300.0, 300.0).take_min(
        [get_canvas_square_dpi(page_context)]
    )
    page_dpi = Resolution(300.0, 300.0).take_min([get_page_square_dpi(page_context)])
    page_context.plugin_manager.rasterize_pdf_page(
        input_file=input_file,
        output_file=output_file,
        raster_device=GhostscriptRasterDevice.JPEGGRAY,
        raster_dpi=canvas_dpi,
        pageno=page_context.pageinfo.pageno + 1,
        page_dpi=page_dpi,
        rotation=0,
        filter_vector=False,
        stop_on_soft_error=not page_context.options.continue_on_soft_render_error,
        options=page_context.options,
        use_cropbox=False,
    )
    return output_file


def describe_rotation(
    page_context: PageContext, orient_conf: OrientationConfidence, correction: int
) -> str:
    """Describe the page rotation we are going to perform (or not perform)."""
    direction = {0: '⇧', 90: '⇨', 180: '⇩', 270: '⇦'}
    turns = {0: ' ', 90: '⬏', 180: '↻', 270: '⬑'}

    existing_rotation = page_context.pageinfo.rotation
    action = ''
    if orient_conf.confidence >= page_context.options.rotate_pages_threshold:
        if correction != 0:
            action = 'will rotate ' + turns[correction]
        else:
            action = 'rotation appears correct'
    else:
        action = "confidence too low to rotate" if correction != 0 else "no change"

    facing = ''

    if existing_rotation != 0:
        facing = f"with existing rotation {direction.get(existing_rotation, '?')}, "
    facing += f"page is facing {direction.get(orient_conf.angle, '?')}"

    return f"{facing}, confidence {orient_conf.confidence:.2f} - {action}"


def get_orientation_correction(preview: Path, page_context: PageContext) -> int:
    """Work out orientation correction for each page.

    We ask Ghostscript to draw a preview page, which will rasterize with the
    current /Rotate applied, and then ask OCR which way the page is
    oriented. If the value of /Rotate is correct (e.g., a user already
    manually fixed rotation), then OCR will say the page is pointing
    up and the correction is zero. Otherwise, the orientation found by
    OCR represents the clockwise rotation, or the counterclockwise
    correction to rotation.

    When we draw the real page for OCR, we rotate it by the CCW correction,
    which points it (hopefully) upright. _graft.py takes care of the orienting
    the image and text layers.
    """
    ocr_engine = page_context.plugin_manager.get_ocr_engine(
        options=page_context.options
    )
    orient_conf = ocr_engine.get_orientation(preview, page_context.options)

    correction = orient_conf.angle % 360
    log.info(describe_rotation(page_context, orient_conf, correction))
    if (
        orient_conf.confidence >= page_context.options.rotate_pages_threshold
        and correction != 0
    ):
        return correction

    return 0


def _use_weighted_dpi(dpi_profile: PageResolutionProfile) -> bool:
    """Decide whether a small high resolution region should not set the page DPI.

    Rendering the whole page at the resolution of a small high-detail patch can
    produce enormous page images, so we fall back to the area-weighted DPI.
    That reasoning does not apply when the maximum-DPI images span essentially
    the whole page (e.g. a full-page text mask over a low resolution
    background): then the maximum DPI is the page's native resolution, and
    rendering at it costs little more than the image already contains. The 0.9
    coverage threshold allows for scans cropped slightly smaller than the page.
    """
    return (
        dpi_profile.average_to_max_dpi_ratio < 0.8
        and dpi_profile.max_dpi_page_coverage < 0.9
    )


def calculate_image_dpi(page_context: PageContext) -> Resolution:
    """Calculate the DPI for the page image."""
    pageinfo = page_context.pageinfo
    dpi_profile = pageinfo.page_dpi_profile()
    if dpi_profile and _use_weighted_dpi(dpi_profile):
        image_dpi = Resolution(dpi_profile.weighted_dpi, dpi_profile.weighted_dpi)
    else:
        image_dpi = pageinfo.dpi
    return image_dpi


def calculate_raster_dpi(page_context: PageContext):
    """Calculate the DPI for rasterization."""
    # Produce the page image with square resolution or else deskew and OCR
    # will not work properly.
    image_dpi = calculate_image_dpi(page_context)
    dpi_profile = page_context.pageinfo.page_dpi_profile()
    canvas_dpi = get_canvas_square_dpi(page_context, image_dpi)
    page_dpi = get_page_square_dpi(page_context, image_dpi)
    if dpi_profile and _use_weighted_dpi(dpi_profile):
        log.warning(
            "Weighted average image DPI is %0.1f, max DPI is %0.1f. "
            "The discrepancy may indicate a high detail region on this page, "
            "but could also indicate a problem with the input PDF file. "
            "Page image will be rendered at %0.1f DPI.",
            dpi_profile.weighted_dpi,
            dpi_profile.max_dpi,
            canvas_dpi.to_scalar(),
        )
    return canvas_dpi, page_dpi


def _select_raster_device(pageinfo: PageInfo) -> GhostscriptRasterDevice:
    """Choose the minimum raster device that preserves the page's color depth.

    The device escalates from 1-bit mono through grayscale, indexed, and full
    color as required by the page's images, image masks, and vector content.
    Image masks are painted with the current fill color, so a mask painted in
    gray or color escalates the device even though the mask itself is 1-bit.
    """
    colorspaces = [
        GhostscriptRasterDevice.PNGMONOD,
        GhostscriptRasterDevice.PNGGRAY,
        GhostscriptRasterDevice.PNG256,
        GhostscriptRasterDevice.PNG16M,
    ]
    device_idx = 0

    def at_least(colorspace):
        return max(device_idx, colorspaces.index(colorspace))

    for image in pageinfo.images:
        if image.type_ == 'stencil':
            # The fill color used to paint the mask, not the 1-bit mask data,
            # determines the color depth OCR needs.
            if image.ink == Ink.color:
                device_idx = at_least(GhostscriptRasterDevice.PNG16M)
            elif image.ink == Ink.gray:
                device_idx = at_least(GhostscriptRasterDevice.PNGGRAY)
            continue
        if image.bpc > 1:
            if image.color == Colorspace.index:
                device_idx = at_least(GhostscriptRasterDevice.PNG256)
            elif image.color == Colorspace.gray:
                device_idx = at_least(GhostscriptRasterDevice.PNGGRAY)
            else:
                device_idx = at_least(GhostscriptRasterDevice.PNG16M)

    if pageinfo.has_vector:
        log.debug(f"Page has vector content, using {GhostscriptRasterDevice.PNG16M}")
        device_idx = at_least(GhostscriptRasterDevice.PNG16M)

    return colorspaces[device_idx]


def rasterize(
    input_file: Path,
    page_context: PageContext,
    correction: int = 0,
    output_tag: str = '',
    remove_vectors: bool | None = None,
) -> Path:
    """Rasterize a PDF page to a PNG image.

    Args:
        input_file: The input PDF file path.
        page_context: The page context object.
        correction: The orientation correction angle. Defaults to 0.
        output_tag: The output tag. Defaults to ''.
        remove_vectors: Whether to remove vectors. Defaults to None, which means
            the value from the page context options will be used. If the value
            is True or False, it will override the page context options.

    Returns:
        Path: The output PNG file path.
    """
    if remove_vectors is None:
        remove_vectors = page_context.options.remove_vectors

    output_file = page_context.get_path(f'rasterize{output_tag}.png')
    pageinfo = page_context.pageinfo

    device = _select_raster_device(pageinfo)

    log.debug(
        f"Rasterize with {device}, rotation {correction}, mediabox {pageinfo.mediabox}"
    )

    canvas_dpi, page_dpi = calculate_raster_dpi(page_context)

    page_context.plugin_manager.rasterize_pdf_page(
        input_file=input_file,
        output_file=output_file,
        raster_device=device,
        raster_dpi=canvas_dpi,
        page_dpi=page_dpi,
        pageno=pageinfo.pageno + 1,
        rotation=correction,
        filter_vector=remove_vectors,
        stop_on_soft_error=not page_context.options.continue_on_soft_render_error,
        options=page_context.options,
        use_cropbox=False,
    )
    return output_file


def preprocess_remove_background(input_file: Path, page_context: PageContext) -> Path:
    """Remove the background from the input image (temporarily disabled)."""
    if any(image.bpc > 1 for image in page_context.pageinfo.images):
        raise NotImplementedError("--remove-background is temporarily not implemented")
        # output_file = page_context.get_path('pp_rm_bg.png')
        # leptonica.remove_background(input_file, output_file)
        # return output_file
    log.info("background removal skipped on mono page")
    return input_file


def preprocess_deskew(input_file: Path, page_context: PageContext) -> Path:
    """Deskews the input image using the OCR engine and saves the output to a file.

    Args:
        input_file: The input image file to deskew.
        page_context: The context of the page being processed.

    Returns:
        Path: The path to the deskewed image file.
    """
    output_file = page_context.get_path('pp_deskew.png')
    dpi = get_page_square_dpi(page_context, calculate_image_dpi(page_context))

    ocr_engine = page_context.plugin_manager.get_ocr_engine(
        options=page_context.options
    )
    deskew_angle_degrees = ocr_engine.get_deskew(input_file, page_context.options)

    with Image.open(input_file) as im:
        # According to Pillow docs, .rotate() will automatically use Image.NEAREST
        # resampling if image is mode '1' or 'P'
        deskewed = im.rotate(
            deskew_angle_degrees,
            resample=Image.Resampling.BICUBIC,
            fillcolor=ImageColor.getcolor('white', mode=im.mode),
        )
        deskewed.save(output_file, dpi=dpi)

    return output_file


def preprocess_clean(input_file: Path, page_context: PageContext) -> Path:
    """Clean the input image using unpaper."""
    output_file = page_context.get_path('pp_clean.png')
    dpi = get_page_square_dpi(page_context, calculate_image_dpi(page_context))
    return unpaper.clean(
        input_file,
        output_file,
        dpi=dpi.to_scalar(),
        unpaper_args=page_context.options.unpaper_args,
    )


def create_ocr_image(image: Path, page_context: PageContext) -> Path:
    """Create the image we send for OCR.

    Might not be the same as the display image depending on preprocessing.
    This image will never be shown to the user.
    """
    output_file = page_context.get_path('ocr.png')
    options = page_context.options
    im: Image.Image
    with Image.open(image) as im:
        log.debug('resolution %r', im.info['dpi'])

        if options.max_ocr_image_mpixels:
            # Bound the memory this page costs from here on. Everything
            # downstream -- masking, the PNG we write, and the OCR engine's own
            # buffers -- scales with the pixel count, and the OCR engine
            # dominates it. Downsampling adjusts the DPI to match, so the
            # recognized text still lands in the right place on the page.
            size = calculate_downsample(
                im, max_pixels=round(options.max_ocr_image_mpixels * 1_000_000)
            )
            if size != im.size:
                log.info(
                    "Downsampling image for OCR from %d x %d to %d x %d to stay "
                    "within --max-ocr-image-mpixels; the visible page is "
                    "unaffected",
                    *im.size,
                    *size,
                )
                im = downsample_image(im, size)

        if not options.is_force_mode:
            # Do not mask text areas when forcing OCR, because we need to OCR
            # all text areas
            mask = None  # Exclude both visible and invisible text from OCR
            if options.mode == ProcessingMode.redo:
                mask = True  # Mask visible text, but not invisible text

            draw = None
            for textarea in page_context.pageinfo.get_textareas(
                visible=mask, corrupt=None
            ):
                # Calculate resolution based on the image size and page dimensions
                # without regard whatever resolution is in pageinfo (may differ or
                # be None)
                bbox = [float(v) for v in textarea]
                xyscale = tuple(float(coord) / 72.0 for coord in im.info['dpi'])
                pixcoords = (
                    bbox[0] * xyscale[0],
                    im.height - bbox[3] * xyscale[1],
                    bbox[2] * xyscale[0],
                    im.height - bbox[1] * xyscale[1],
                )
                log.debug('blanking %r', pixcoords)
                if draw is None:
                    # Constructing the drawing context decodes the image, so wait
                    # until we know there is something to blank.
                    draw = ImageDraw.ImageDraw(im)
                draw.rectangle(pixcoords, fill='white')
                # draw.rectangle(pixcoords, outline='pink')

        filter_im = page_context.plugin_manager.filter_ocr_image(
            page=page_context, image=im
        )
        if filter_im is not None and filter_im is not im:
            im = filter_im
        elif not has_decoded_pixels(im):
            # Nothing read or wrote a pixel: no masking was needed, and no filter
            # replaced or touched the image. Re-encoding it would reproduce the
            # file we already have, which on a large page costs seconds of CPU and
            # a full-size buffer, so link to it instead.
            log.debug("OCR image needs no changes, linking to %s", image)
            safe_symlink(image, output_file)
            return output_file

        # Pillow requires integer DPI
        dpi = tuple(round(coord) for coord in im.info['dpi'])
        im.save(output_file, dpi=dpi)
    return output_file


def ocr_engine_hocr(input_file: Path, page_context: PageContext) -> tuple[Path, Path]:
    """Run the OCR engine and generate hOCR output."""
    hocr_out = page_context.get_path('ocr_hocr.hocr')
    hocr_text_out = page_context.get_path('ocr_hocr.txt')
    options = page_context.options

    ocr_engine = page_context.plugin_manager.get_ocr_engine(options=options)
    ocr_engine.generate_hocr(
        input_file=input_file,
        output_hocr=hocr_out,
        output_text=hocr_text_out,
        options=options,
    )
    return hocr_out, hocr_text_out


def ocr_engine_direct(
    input_file: Path, page_context: PageContext
) -> tuple[OcrElement, Path]:
    """Run the OCR engine and return OcrElement tree directly.

    This is the modern path for OCR engines that support the generate_ocr() API.
    It bypasses hOCR file generation for better performance and richer data.

    Args:
        input_file: The image file to OCR.
        page_context: The page context with options and path utilities.

    Returns:
        A tuple of (OcrElement tree, path to text sidecar file).
    """
    text_out = page_context.get_path('ocr_direct.txt')
    options = page_context.options

    ocr_engine = page_context.plugin_manager.get_ocr_engine(options=options)
    ocr_tree, text_content = ocr_engine.generate_ocr(
        input_file=input_file,
        options=options,
        page_number=page_context.pageno,
    )

    # Write text sidecar file
    text_out.write_text(text_content, encoding='utf-8')

    return ocr_tree, text_out


def should_visible_page_image_use_jpg(pageinfo: PageInfo) -> bool:
    """Determines whether the visible page image should be saved as a JPEG.

    If all images were JPEGs originally (including FlateDecode+DCTDecode),
    permit a JPEG as output.

    Args:
        pageinfo: The PageInfo object containing information about the page.

    Returns:
        A boolean indicating whether the visible page image should be saved as a JPEG.
    """
    return bool(pageinfo.images) and all(
        im.enc in (Encoding.jpeg, Encoding.flate_jpeg) for im in pageinfo.images
    )


def create_visible_page_jpg(image: Path, page_context: PageContext) -> Path:
    """Create a visible page image in JPEG format.

    This is intended to be used when all images on the page were originally JPEGs.
    """
    output_file = page_context.get_path('visible.jpg')
    with Image.open(image) as im:
        # At this point the image should be a .png, but deskew, unpaper
        # might have removed the DPI information. In this case, fall back to
        # square DPI used to rasterize. When the preview image was
        # rasterized, it was also converted to square resolution, which is
        # what we want to give to the OCR engine, so keep it square.
        if 'dpi' in im.info:
            dpi = Resolution(*im.info['dpi'])
        else:
            # Fallback to page-implied DPI
            dpi = get_page_square_dpi(page_context, calculate_image_dpi(page_context))

        # Pillow requires integer DPI
        im.save(output_file, format='JPEG', dpi=dpi.to_int())
    return output_file


def create_pdf_page_from_image(
    image: Path, page_context: PageContext, orientation_correction: int
) -> Path:
    """Create a PDF page from a page image."""
    # We rasterize a square DPI version of each page because most image
    # processing tools don't support rectangular DPI. Use the square DPI as it
    # accurately describes the image. It would be possible to resample the image
    # at this stage back to non-square DPI to more closely resemble the input,
    # except that the hocr renderer does not understand non-square DPI. The
    # sandwich renderer would be fine.
    output_file = page_context.get_path('visible.pdf')

    pageinfo = page_context.pageinfo
    pagesize = 72.0 * float(pageinfo.width_inches), 72.0 * float(pageinfo.height_inches)
    effective_rotation = (pageinfo.rotation - orientation_correction) % 360
    swap_axis = effective_rotation % 180 == 90
    if swap_axis:
        pagesize = pagesize[1], pagesize[0]

    # Create a new single page PDF to hold
    bio = BytesIO()
    with image.open('rb') as imfile:
        log.debug('convert')

        layout_fun = img2pdf.get_layout_fun(pagesize)
        img2pdf.convert(
            imfile,
            layout_fun=layout_fun,
            outputstream=bio,
            engine=img2pdf.Engine.pikepdf,
            rotation=img2pdf.Rotation.ifvalid,
        )
        log.debug('convert done')

    # img2pdf does not generate boxes correctly, so we fix them
    bio.seek(0)
    fix_pagepdf_boxes(bio, output_file, page_context, swap_axis=swap_axis)

    output_file = page_context.plugin_manager.filter_pdf_page(
        page=page_context, image_filename=image, output_pdf=output_file
    )
    return output_file


def ocr_engine_textonly_pdf(
    input_image: Path, page_context: PageContext
) -> tuple[Path, Path]:
    """Run the OCR engine and generate a text-only PDF (will look blank)."""
    output_pdf = page_context.get_path('ocr_tess.pdf')
    output_text = page_context.get_path('ocr_tess.txt')
    options = page_context.options

    ocr_engine = page_context.plugin_manager.get_ocr_engine(options=options)
    ocr_engine.generate_pdf(
        input_file=input_image,
        output_pdf=output_pdf,
        output_text=output_text,
        options=options,
    )
    return output_pdf, output_text


def _offset_rect(rect: tuple[float, float, float, float], offset: tuple[float, float]):
    """Offset a rectangle by a given amount."""
    return (
        rect[0] + offset[0],
        rect[1] + offset[1],
        rect[2] + offset[0],
        rect[3] + offset[1],
    )


def _adjust_pagebox(
    page: pikepdf.Page,
    media_box: FloatRect,
    name: pikepdf.Name,
    target_box: FloatRect,
    offset: tuple[float, float],
    swap_axis: bool,
):
    if media_box == target_box:
        return
    box = _offset_rect(target_box, offset)
    if swap_axis:
        box = box[1], box[0], box[3], box[2]
    page[name] = box
    log.debug(f"{str(name)} = {target_box}")


def fix_pagepdf_boxes(
    infile: Path | BinaryIO,
    out_file: Path,
    page_context: PageContext,
    swap_axis: bool = False,
) -> Path:
    """Fix the bounding boxes in a single page PDF.

    The single page PDF is created with a normal MediaBox with its lower left corner
    at (0, 0). infile is the single page PDF. page_context.mediabox has the original
    file's mediabox, which may have a different origin. We need to adjust the other
    boxes in the single page PDF to match the effect they had on the original page.

    When correcting page rotation, we create a single page PDF that is correctly
    rotated instead of an incorrectly rotated and then setting page.Rotate on it.
    If rotation is either 90 or 270 degrees, then this function can be called
    with swap_axis to swap the X and Y coordinates of all the boxes.

    We are not concerned with solving degenerate cases where the boxes overlap or
    or express invalid rectangles. We merely pass the boxes, producing a
    transformation equivalent to the change made by constructing a new page image.
    """
    with pikepdf.open(infile, conversion_mode='explicit') as pdf:
        for page in pdf.pages:
            log.debug(
                f"initial mediabox={page.MediaBox} and pageinfo "
                f"mediabox={page_context.pageinfo.mediabox}"
            )
            mediabox = page_context.pageinfo.mediabox
            offset = -mediabox[0], -mediabox[1]
            if swap_axis:
                mediabox = mediabox[1], mediabox[0], mediabox[3], mediabox[2]
            boxes = ['CropBox', 'TrimBox', 'ArtBox', 'BleedBox']
            for box_name in boxes:
                _adjust_pagebox(
                    page,
                    mediabox,
                    pikepdf.Name(f"/{box_name}"),
                    getattr(page_context.pageinfo, box_name.lower()),
                    offset,
                    swap_axis,
                )

        pdf.save(out_file)
    return out_file


def generate_postscript_stub(context: PdfContext) -> Path:
    """Generates a PostScript file stub for the given PDF context.

    Args:
        context: The PDF context to generate the PostScript file stub for.

    Returns:
        Path: The path to the generated PostScript file stub.
    """
    output_file = context.get_path('pdfa.ps')
    generate_pdfa_ps(output_file)
    return output_file


def convert_to_pdfa(input_pdf: Path, input_ps_stub: Path, context: PdfContext) -> Path:
    """Converts the given PDF to PDF/A.

    Args:
        input_pdf: The input PDF file path (presumably not PDF/A).
        input_ps_stub: The input PostScript file path, containing instructions
            for the PDF/A generator to use.
        context: The PDF context.
    """
    options = context.options
    input_pdfinfo = context.pdfinfo
    fix_docinfo_file = context.get_path('fix_docinfo.pdf')
    output_file = context.get_path('pdfa.pdf')

    # If the DocumentInfo record contains NUL characters, Ghostscript will
    # produce XMP metadata which contains invalid XML entities (&#0;).
    # NULs in DocumentInfo seem to be common since older Acrobats included them.
    # pikepdf can deal with this, but we make the world a better place by
    # stamping them out as soon as possible.
    with pikepdf.open(input_pdf, conversion_mode='explicit') as pdf_file:
        # Ghostscript would substitute and re-embed any non-embedded CID font to
        # satisfy PDF/A, corrupting CJK text (e.g. an Acrobat OCR layer) in the
        # process. Refuse rather than silently damage the user's text layer.
        nonembedded = find_nonembedded_cid_fonts(pdf_file)
        if nonembedded:
            raise NonEmbeddedFontsError(nonembedded)
        # Ghostscript loses the Unicode meaning of glyph names in the simple
        # fonts it rewrites, unless it is given as /ToUnicode (issue #1297).
        added_tounicode = add_simple_font_tounicode(pdf_file)
        if added_tounicode:
            log.debug('Added /ToUnicode to %d font(s)', added_tounicode)
        modified = repair_docinfo_nuls(pdf_file) or bool(added_tounicode)
        # Ghostscript drops annotations without the Print flag, hyperlinks
        # included, when it converts to PDF/A. Unless Ghostscript was chosen,
        # speculative conversion has already reported hidden annotations.
        if repair_annotations_for_ghostscript(
            pdf_file, report_removed=options.pdfa_backend == 'ghostscript'
        ):
            modified = True
        if modified:
            pdf_file.save(fix_docinfo_file)
        else:
            safe_symlink(input_pdf, fix_docinfo_file)

    # Extract PDF/A part correctly
    if options.output_type.startswith('pdfa'):
        if options.output_type == 'pdfa':
            pdfa_part = '2'  # Default to PDF/A-2
        else:
            pdfa_part = options.output_type.split('-')[
                -1
            ]  # Extract number from pdfa-1, pdfa-2, etc.
    else:
        pdfa_part = '2'  # Fallback

    context.plugin_manager.generate_pdfa(
        pdf_version=input_pdfinfo.min_version,
        pdf_pages=[fix_docinfo_file],
        pdfmark=input_ps_stub,
        output_file=output_file,
        context=context,
        pdfa_part=pdfa_part,
        progressbar_class=(
            context.plugin_manager.get_progressbar_class()
            if options.progress_bar
            else None
        ),
        stop_on_soft_error=not options.continue_on_soft_render_error,
    )

    return output_file


def _internal_backend_failed(reason: str) -> PdfaConversionFailedError:
    return PdfaConversionFailedError(
        f"--pdfa-backend internal could not produce PDF/A: {reason}\n"
        "Use --pdfa-backend auto or ghostscript to convert with Ghostscript, "
        "or --output-type pdf to skip PDF/A."
    )


def _describe_unapproved(report: Report) -> str:
    """Say why pikepdf's PDF/A validator did not approve a file."""
    if report.verdict == 'not_checked':
        return (
            f"it contains {len(report.unsupported)} construct(s) pikepdf's "
            "validator does not check, so it could not be confirmed as PDF/A"
        )
    return f"it failed validation with {len(report.violations)} violation(s)"


def try_speculative_pdfa(input_pdf: Path, context: PdfContext) -> Path | None:
    """Try PDF/A conversion without Ghostscript, validated by pikepdf.

    This repairs and declares the PDF/A structures directly with
    `pikepdf.pdfa.save`, which validates the bytes it writes and keeps them
    only if they pass. If validation passes, returns the converted file. If
    the verdict is 'fail' or 'not_checked', returns None to signal that
    Ghostscript should be used, or, for the 'pdfa' output types with
    ``--pdfa-backend internal``, raises.

    With ``--pdfa-backend ghostscript`` nothing is attempted and None is
    returned.

    Args:
        input_pdf: Path to the PDF to convert
        context: The PDF context

    Returns:
        Path to valid PDF/A file, or None if speculative conversion failed

    Raises:
        PdfaConversionFailedError: If ``--pdfa-backend internal`` is required to
            produce PDF/A (a 'pdfa' output type) and could not.
    """
    from pikepdf.pdfa import PdfaError

    options = context.options
    if options.pdfa_backend == 'ghostscript':
        log.debug('Using Ghostscript for PDF/A, as --pdfa-backend ghostscript')
        return None
    required = options.pdfa_backend == 'internal' and options.output_type.startswith(
        'pdfa'
    )
    fallback = '' if options.pdfa_backend == 'internal' else '; using Ghostscript'

    output_file = context.get_path('speculative_pdfa.pdf')
    flavour = output_type_to_flavour(options.output_type)
    try:
        speculative_pdfa_conversion(input_pdf, output_file, options.output_type)
    except PdfaError as e:
        report = e.report
        log_prepare_result(report.prepared)
    except Exception as e:  # pylint: disable=broad-except
        if required:
            raise _internal_backend_failed(f"the conversion failed ({e})") from e
        log.debug('Speculative PDF/A conversion failed: %s', e)
        return None
    else:
        log.info('Speculative PDF/A conversion succeeded - skipping Ghostscript')
        return output_file

    if required:
        raise _internal_backend_failed(
            f"{_describe_unapproved(report)}.\n" + report.summary()
        )
    log.info(
        'Speculative PDF/A-%s conversion was not used: %s%s',
        flavour.value,
        _describe_unapproved(report),
        fallback,
    )
    log.debug('%s', report.summary(limit=len(report.findings)))
    return None


def _ghostscript_pdfa_fallback(input_pdf: Path, context: PdfContext) -> Path | None:
    """Best-effort PDF/A conversion via Ghostscript for 'auto' output type.

    Returns the converted PDF/A path, or None if Ghostscript is unavailable,
    fails, or cannot produce valid PDF/A. Never raises: 'auto' mode degrades to
    a regular PDF instead of erroring or emitting corrupted output.

    Args:
        input_pdf: Path to the PDF to convert.
        context: The PDF context.
    """
    from ocrmypdf._exec import ghostscript

    if not ghostscript.available():
        return None
    try:
        ps_stub = generate_postscript_stub(context)
        gs_out = convert_to_pdfa(input_pdf, ps_stub, context)
    except (
        SubprocessOutputError,
        ColorConversionNeededError,
        NonEmbeddedFontsError,
    ) as e:
        log.info('Auto mode: Ghostscript could not produce PDF/A (%s)', e)
        return None
    if not file_claims_pdfa(gs_out)['pass']:
        log.info('Auto mode: Ghostscript output is not valid PDF/A')
        return None
    return gs_out


def _auto_keeps_regular_pdf(input_pdf: Path) -> bool:
    """Return True if 'auto' output type must not attempt PDF/A at all.

    Non-embedded CID fonts cannot be made PDF/A without Ghostscript font
    substitution that corrupts CID/CJK text. Rather than risk an existing
    text layer, 'auto' downgrades to a regular PDF (the same outcome as any
    other case where best-effort PDF/A is not achievable).
    """
    with pikepdf.open(input_pdf, conversion_mode='explicit') as pdf_file:
        nonembedded = find_nonembedded_cid_fonts(pdf_file)
    if nonembedded:
        log.info(
            "Auto mode: input has non-embedded CID fonts (%s) that cannot be "
            "converted to PDF/A without corrupting the text; outputting a "
            "regular PDF. Use --output-type pdf to select this explicitly.",
            ', '.join(sorted(nonembedded)),
        )
        return True
    return False


def _pdfa_without_speculation(input_pdf: Path, context: PdfContext) -> Path | None:
    """Convert to PDF/A with Ghostscript, after speculative conversion failed.

    For the 'pdfa' output types, Ghostscript must succeed, and errors are
    raised. For 'auto', Ghostscript is best-effort (unless ``--pdfa-backend
    internal`` rules it out), and None means a regular PDF is to be output.

    Args:
        input_pdf: The PDF that speculative conversion started from.
        context: The PDF context.

    Returns:
        The PDF/A file, or None for a regular PDF.
    """
    options = context.options
    if options.output_type.startswith('pdfa'):
        ps_stub_out = generate_postscript_stub(context)
        return convert_to_pdfa(input_pdf, ps_stub_out, context)
    if options.pdfa_backend != 'internal':
        gs_out = _ghostscript_pdfa_fallback(input_pdf, context)
        if gs_out is not None:
            log.info('Auto mode: produced PDF/A via Ghostscript')
            return gs_out
    log.info('Auto mode: could not produce PDF/A, outputting regular PDF')
    return None


def _fix_metadata_and_optimize(
    input_pdf: Path,
    context: PdfContext,
    executor: Executor,
    pdfa_output_type: str | None,
    optimize_filename: str = 'optimize.pdf',
) -> tuple[Path, Sequence[str]]:
    """Run the metadata fixup and the optimizer, the last steps of the pipeline.

    A PDF/A file is saved with the settings pikepdf pins for its flavour, so
    that the bytes written remain valid PDF/A.

    ``optimize_filename`` names the optimizer's output in the working folder.
    """
    optimizing = context.plugin_manager.is_optimization_enabled(context=context)
    output_type = context.options.output_type
    save_settings = get_pdf_save_settings(
        pdfa_output_type or ('pdf' if output_type == 'auto' else output_type)
    )
    save_settings['linearize'] = not optimizing and should_linearize(input_pdf, context)
    pdf_out = metadata_fixup(
        input_pdf,
        context,
        pdf_save_settings=save_settings,
        pdfa_output_type=pdfa_output_type,
    )
    return optimize_pdf(pdf_out, context, executor, optimize_filename)


def _final_speculative_pdfa_passes(output_pdf: Path, context: PdfContext) -> bool:
    """Validate the final file of a speculative PDF/A conversion.

    The metadata fixup and the optimizer rewrite the candidate that
    `try_speculative_pdfa` approved, so the file that is output is validated
    again, with `pikepdf.pdfa.validate_written`. A 'not_checked' verdict is
    treated like 'fail'.

    Raises:
        PdfaConversionFailedError: If ``--pdfa-backend internal`` is required to
            produce PDF/A (a 'pdfa' output type) and the file is not approved.
    """
    from pikepdf.pdfa import validate_written

    options = context.options
    flavour = output_type_to_flavour(options.output_type)
    report = validate_written(output_pdf, flavour)
    if report.verdict == 'pass':
        log.debug('Final PDF/A-%s output validated', flavour.value)
        return True
    if options.pdfa_backend == 'internal' and options.output_type.startswith('pdfa'):
        raise _internal_backend_failed(
            f"after metadata and optimization, {_describe_unapproved(report)}.\n"
            + report.summary()
        )
    fallback = '' if options.pdfa_backend == 'internal' else '; using Ghostscript'
    log.info(
        'Speculative PDF/A-%s output was not used after metadata and '
        'optimization: %s%s',
        flavour.value,
        _describe_unapproved(report),
        fallback,
    )
    log.info('%s', report.summary())
    return False


def finish_output_pdf(
    input_pdf: Path, context: PdfContext, executor: Executor
) -> tuple[Path, Sequence[str]]:
    """Produce the output file: convert to PDF/A if needed, fix metadata, optimize.

    For the 'pdfa' output types and 'auto', PDF/A is attempted first by
    speculative conversion (`try_speculative_pdfa`). Its candidate then goes
    through the metadata fixup and the optimizer, and the final file is
    validated again, since it is the file that is output. If speculative
    conversion or the final validation fails, Ghostscript converts
    *input_pdf* instead, and its output goes through the same final steps:

    - for the 'pdfa' output types, Ghostscript is required, or with
      ``--pdfa-backend internal``, PdfaConversionFailedError is raised;
    - for 'auto', Ghostscript is best-effort, and a regular PDF is output if
      it is unavailable, fails, or is ruled out by ``--pdfa-backend internal``.
      Inputs with non-embedded CID fonts are output as regular PDF without
      attempting PDF/A.

    For 'auto', the output type achieved, 'pdfa' or 'pdf', is recorded as
    ``_actual_output_type`` in the options' ``extra_attrs``.

    Args:
        input_pdf: The PDF to finish.
        context: The PDF context.
        executor: The executor for the optimizer.

    Returns:
        The output file and the optimizer's messages.
    """
    options = context.options
    output_type = options.output_type
    auto = output_type == 'auto'
    if not auto and not output_type.startswith('pdfa'):
        return _fix_metadata_and_optimize(input_pdf, context, executor, None)
    pdfa_output_type = 'pdfa' if auto else output_type

    def finish(pdf: Path | None, *, retry: bool = False) -> tuple[Path, Sequence[str]]:
        if auto:
            options.extra_attrs['_actual_output_type'] = (
                'pdf' if pdf is None else 'pdfa'
            )
        # The Ghostscript fallback after a rejected speculative candidate
        # reruns these steps; the optimizer output of the first run is a
        # real file on Windows, which safe_symlink will not overwrite.
        optimize_filename = 'optimize-fallback.pdf' if retry else 'optimize.pdf'
        if pdf is None:
            return _fix_metadata_and_optimize(
                input_pdf, context, executor, None, optimize_filename
            )
        return _fix_metadata_and_optimize(
            pdf, context, executor, pdfa_output_type, optimize_filename
        )

    if auto and _auto_keeps_regular_pdf(input_pdf):
        return finish(None)

    speculative = try_speculative_pdfa(input_pdf, context)
    if speculative is not None:
        result = finish(speculative)
        if _final_speculative_pdfa_passes(result[0], context):
            return result

    gs_out = _pdfa_without_speculation(input_pdf, context)
    if gs_out is not None and not file_claims_pdfa(gs_out)['pass']:
        # Ghostscript was asked for PDF/A and did not declare it. Leave the
        # metadata undeclared too, so that the failure is reported.
        if auto:
            options.extra_attrs['_actual_output_type'] = 'pdf'
        optimize_filename = (
            'optimize-fallback.pdf' if speculative is not None else 'optimize.pdf'
        )
        return _fix_metadata_and_optimize(
            gs_out, context, executor, None, optimize_filename
        )
    return finish(gs_out, retry=speculative is not None)


def should_linearize(working_file: Path, context: PdfContext) -> bool:
    """Determine whether the PDF should be linearized.

    For smaller files, linearization is not worth the effort.
    """
    filesize = working_file.stat().st_size
    return filesize > (context.options.fast_web_view * 1_000_000)


def _file_size_ratio(
    input_file: Path, output_file: Path
) -> tuple[float | None, float | None]:
    """Calculate ratio of input to output file sizes and percentage savings.

    Args:
        input_file (Path): The path to the input file.
        output_file (Path): The path to the output file.

    Returns:
        tuple[float | None, float | None]: A tuple containing the file size
        ratio and the percentage savings achieved by the output file size
        compared to the input file size.
    """
    input_size = input_file.stat().st_size
    output_size = output_file.stat().st_size
    if output_size == 0:
        return None, None
    ratio = input_size / output_size
    savings = 1 - output_size / input_size
    return ratio, savings


def optimize_pdf(
    input_file: Path,
    context: PdfContext,
    executor: Executor,
    output_filename: str = 'optimize.pdf',
) -> tuple[Path, Sequence[str]]:
    """Optimize the given PDF file."""
    output_file = context.get_path(output_filename)
    output_pdf, messages = context.plugin_manager.optimize_pdf(
        input_pdf=input_file,
        output_pdf=output_file,
        context=context,
        executor=executor,
        linearize=should_linearize(input_file, context),
    )

    ratio, savings = _file_size_ratio(input_file, output_file)
    if ratio:
        log.info(f"Image optimization ratio: {ratio:.2f} savings: {(savings):.1%}")
    ratio, savings = _file_size_ratio(context.origin, output_file)
    if ratio:
        log.info(f"Total file size ratio: {ratio:.2f} savings: {(savings):.1%}")
    return output_pdf, messages


def enumerate_compress_ranges(
    iterable: Iterable[T],
) -> Iterator[tuple[tuple[int, int], T | None]]:
    """Enumerate the ranges of non-empty elements in an iterable.

    Compresses consecutive ranges of length 1 into single elements.

    Args:
        iterable: An iterable of elements to enumerate.

    Yields:
        A tuple containing a range of indices and the corresponding element.
        If the element is None, the range represents a skipped range of indices.
    """
    skipped_from: int | None = None
    index: int | None = None
    for index, txt_file in enumerate(iterable):
        index += 1
        if txt_file:
            if skipped_from is not None:
                yield (skipped_from, index - 1), None
                skipped_from = None
            yield (index, index), txt_file
        else:
            if skipped_from is None:
                skipped_from = index
    if skipped_from is not None:
        # skipped_from can only be set inside the loop above, so the loop
        # must have run at least once and index is guaranteed to be an int.
        assert index is not None
        yield (skipped_from, index), None


def merge_sidecars(txt_files: Iterable[Path | None], context: PdfContext) -> Path:
    """Merge the page sidecar files into a single file.

    Sidecar files are created by the OCR engine and contain the text for each
    page in the PDF. This function merges the sidecar files into a single file
    and returns the path to the merged file.
    """
    output_file = context.get_path('sidecar.txt')
    with output_file.open('w', encoding="utf-8") as stream:
        for (from_, to_), txt_file in enumerate_compress_ranges(txt_files):
            if from_ != 1:
                stream.write('\f')  # Form feed between pages for all pages after first
            if txt_file:
                txt = txt_file.read_text(encoding="utf-8")
                # Some versions of Tesseract add a form feed at the end and
                # others don't. Remove it if it exists, since we add one manually.
                stream.write(txt.removesuffix('\f'))
            else:
                pages = f"{from_}-{to_}" if from_ != to_ else f"{from_}"
                stream.write(f'[OCR skipped on page(s) {pages}]')
    return output_file


def copy_final(input_file: Path, output_file: PathOrIO) -> None:
    """Copy the final temporary file to the output destination.

    Args:
        input_file: The intermediate input file to copy.
        output_file: The output file to copy to.
    """
    log.debug('%s -> %s', input_file, output_file)
    with input_file.open('rb') as input_stream:
        if output_file == '-':
            fd = get_protected_stdout_fd()
            if fd is not None:
                # Stdout protection is active: write to the preserved real
                # stdout. dup the saved fd so the with-block's close() does not
                # close our long-lived descriptor.
                with os.fdopen(os.dup(fd), 'wb') as stdout_stream:
                    copyfileobj(input_stream, stdout_stream)
                    stdout_stream.flush()
            else:
                # No protection installed (e.g. plain API use): legacy behavior.
                copyfileobj(input_stream, sys.stdout.buffer)  # type: ignore[misc]
                sys.stdout.flush()
        elif hasattr(output_file, 'writable'):
            output_stream = cast(BinaryIO, output_file)
            copyfileobj(input_stream, output_stream)  # type: ignore[misc]
            with suppress(AttributeError):
                output_stream.flush()
        else:
            # At this point we overwrite the output_file specified by the user
            # use copyfileobj because then we use open() to create the file and
            # get the appropriate umask, ownership, etc.
            # The `hasattr` check above already ruled out stream-like objects.
            assert isinstance(output_file, str | bytes | os.PathLike)
            with Path(os.fsdecode(output_file)).open('w+b') as output_stream:
                copyfileobj(input_stream, output_stream)
